# ✈️ TravelPass – Traveller Login & Profile

## 📌 Project Overview

TravelPass is an Android application developed using **Kotlin and XML layouts**. It allows travellers to log in, manage their personal profiles, customize travel preferences, and save their information using SharedPreferences.

The application provides a simple and user-friendly interface with a travel-themed design.

## 🎯 Objectives

- Develop a simple traveller login system.
- Allow users to create and manage their profiles.
- Store user preferences locally.
- Display personalized welcome messages.
- Provide settings to customize travel preferences.
- Implement menu options for profile editing, settings, and logout.

## 🛠️ Technologies Used

| Technology | Purpose |
|---|---|
| Android Studio | Development environment |
| Kotlin | Programming language |
| XML | UI design |
| SharedPreferences | Local data storage |
| Android Intents | Activity navigation |
| Material Components | UI styling |

## ✨ Features

### 1. Login Screen
- Username and password fields.
- Remember Me checkbox.
- Input validation.
- Saves username using SharedPreferences.

### 2. Traveller Profile
- Enter traveller's full name.
- Select distance unit (Kilometres or Miles).
- Enable or disable travel alerts.
- Save profile information.

### 3. Welcome Screen
- Displays a personalized greeting.
- Shows the saved traveller name.
- Displays preferred distance unit.
- Shows travel alert status.

### 4. Options Menu
Provides three menu options:
- **Edit Profile:** Update traveller information.
- **Settings:** Change travel preferences.
- **Logout:** Log out with confirmation.

### 5. Settings Screen
- Change distance unit.
- Enable or disable travel alerts.
- Save updated preferences.
- Navigate back to the Welcome Screen.

### 6. Data Persistence
SharedPreferences stores:
- Username
- Remember Me status
- Traveller name
- Distance unit
- Travel alerts preference

## 📱 Application Screens

The application contains four main activities:

1. MainActivity – Login Screen
2. ProfileActivity – Traveller Profile
3. WelcomeActivity – Welcome Screen
4. SettingsActivity – Settings Screen

## 🔄 Application Workflow

```text
       Login Screen
            |
            v
      Profile Screen
            |
            v
      Welcome Screen
            |
       Options Menu
       /     |      \
      /      |       \
 Edit     Settings   Logout
Profile      |         |
      \      |         v
       \     |     Login Screen
        Welcome
         Screen
```

## 💾 SharedPreferences

**Preference File:** `TravelPassPrefs`

| Key | Data Type |
|---|---|
| remember_me | Boolean |
| saved_username | String |
| profile_name | String |
| unit_distance | String |
| receive_alerts | Boolean |

SharedPreferences allows the application to retain saved information even after closing and reopening the application.

## 📂 Project Structure

```text
TravelPass/
│
├── app/
│   └── src/
│       └── main/
│           ├── java/com/example/travelpass/
│           │   ├── MainActivity.kt
│           │   ├── ProfileActivity.kt
│           │   ├── WelcomeActivity.kt
│           │   └── SettingsActivity.kt
│           │
│           ├── res/
│           │   ├── layout/
│           │   │   ├── activity_main.xml
│           │   │   ├── activity_profile.xml
│           │   │   ├── activity_welcome.xml
│           │   │   └── activity_settings.xml
│           │   │
│           │   ├── menu/
│           │   │   └── main_menu.xml
│           │   │
│           │   ├── drawable/
│           │   └── values/
│           │
│           └── AndroidManifest.xml
│
└── README.md
```

## ⚙️ Installation and Execution

1. Install Android Studio.
2. Download or clone this repository.
3. Open Android Studio.
4. Select **Open Project** and choose the TravelPass folder.
5. Wait for Gradle synchronization.
6. Connect an Android device or start an emulator.
7. Click the Run button.
8. Test the application features.

## 🧪 Testing

The following functionalities were checked:

- Login validation.
- Remember Me functionality.
- Profile creation and editing.
- Distance unit selection.
- Travel alerts selection.
- Personalized welcome message.
- Options Menu navigation.
- Settings update.
- Logout confirmation.
- SharedPreferences data persistence.

**Build Verification:** `./gradlew app:assembleDebug`

**Build Status:** Successful – 0 compilation errors.

## 🎓 Concepts Learned

- Android Activity Lifecycle basics.
- XML-based UI development.
- Kotlin programming.
- Explicit Intents.
- SharedPreferences.
- CheckBox and RadioGroup.
- Options Menu.
- AlertDialog and Toast.
- Data persistence.

## 🚀 Future Enhancements

- Google Maps integration.
- Travel destination recommendations.
- Weather information.
- Hotel and restaurant recommendations.
- Online user authentication.
- SQLite database integration.

## 👩‍💻 Developer

**Name:** Gayathri R

**Course:** Master of Computer Applications (MCA)

**University:** Jain University

