package com.example.travelpass

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private var passedUsername: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Initialize SharedPreferences and receive EXTRA_USERNAME from Intent
        prefs = getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
        passedUsername = intent.getStringExtra("EXTRA_USERNAME")

        val tvUsernameDisplay = findViewById<TextView>(R.id.tvUsernameDisplay)
        val etFullName = findViewById<EditText>(R.id.etFullName)
        val rbKm = findViewById<RadioButton>(R.id.rbKm)
        val rbMiles = findViewById<RadioButton>(R.id.rbMiles)
        val cbReceiveAlerts = findViewById<CheckBox>(R.id.cbReceiveAlerts)
        val btnSaveProfile = findViewById<Button>(R.id.btnSaveProfile)

        // Display logged in username
        val currentUsername = if (!passedUsername.isNullOrEmpty()) passedUsername else prefs.getString(MainActivity.KEY_SAVED_USERNAME, "Traveller")
        tvUsernameDisplay.text = getString(R.string.logged_in_as, currentUsername)

        // Restore previously saved profile details if available
        if (prefs.contains("profile_name")) {
            etFullName.setText(prefs.getString("profile_name", ""))

            val dist = prefs.getString("unit_distance", "km")
            if (dist == "mi" || dist == "miles") {
                rbMiles.isChecked = true
            } else {
                rbKm.isChecked = true
            }

            cbReceiveAlerts.isChecked = prefs.getBoolean("receive_alerts", false)
        } else if (!passedUsername.isNullOrEmpty()) {
            etFullName.setText(passedUsername)
        }

        // Handle Save Profile button click
        btnSaveProfile.setOnClickListener {
            val fullName = etFullName.text.toString().trim()

            // 1. Validate full name is not empty
            if (fullName.isEmpty()) {
                Toast.makeText(this, "Please enter your full name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 2. Determine selected travel unit and alerts
            val distanceUnit = if (rbKm.isChecked) "km" else "mi"
            val receiveAlerts = cbReceiveAlerts.isChecked

            // 3. Save profile preferences to SharedPreferences
            prefs.edit().apply {
                putString("profile_name", fullName)
                putString("unit_distance", distanceUnit)
                putBoolean("receive_alerts", receiveAlerts)
                apply()
            }

            Toast.makeText(this, "Profile Saved", Toast.LENGTH_SHORT).show()

            // 4. Navigate to WelcomeActivity using explicit Intent
            val intent = Intent(this, WelcomeActivity::class.java).apply {
                putExtra("EXTRA_USERNAME", passedUsername ?: currentUsername)
            }
            startActivity(intent)
            finish()
        }
    }
}