package com.example.travelpass

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        const val PREFS_NAME = "TravelPassPrefs"
        const val KEY_REMEMBER = "remember_me"
        const val KEY_SAVED_USERNAME = "saved_username"
    }

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val cbRememberMe = findViewById<CheckBox>(R.id.cbRememberMe)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // 1. Pre-fill username and check Remember Me if saved previously
        val isRemembered = prefs.getBoolean(KEY_REMEMBER, false)
        if (isRemembered) {
            etUsername.setText(prefs.getString(KEY_SAVED_USERNAME, ""))
            cbRememberMe.isChecked = true
        }

        // 2. Handle Login button click
        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            // Validate non-empty credentials
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Save or remove username from SharedPreferences based on Remember Me CheckBox
            prefs.edit().apply {
                if (cbRememberMe.isChecked) {
                    putBoolean(KEY_REMEMBER, true)
                    putString(KEY_SAVED_USERNAME, username)
                } else {
                    remove(KEY_REMEMBER)
                    remove(KEY_SAVED_USERNAME)
                }
                apply()
            }

            // Navigate to ProfileActivity using explicit Intent with EXTRA_USERNAME
            val intent = Intent(this, ProfileActivity::class.java).apply {
                putExtra("EXTRA_USERNAME", username)
            }
            startActivity(intent)
        }
    }
}