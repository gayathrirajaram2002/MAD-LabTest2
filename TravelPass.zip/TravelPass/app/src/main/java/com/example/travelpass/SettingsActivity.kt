package com.example.travelpass

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private var passedUsername: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
        passedUsername = intent.getStringExtra("EXTRA_USERNAME")

        val rbSettingsKm = findViewById<RadioButton>(R.id.rbSettingsKm)
        val rbSettingsMiles = findViewById<RadioButton>(R.id.rbSettingsMiles)
        val cbSettingsAlerts = findViewById<CheckBox>(R.id.cbSettingsAlerts)
        val btnSaveSettings = findViewById<Button>(R.id.btnSaveSettings)
        val btnBackToHome = findViewById<Button>(R.id.btnBackToHome)

        // Load and display currently saved preferences
        val savedDist = prefs.getString("unit_distance", "km")
        if (savedDist == "mi" || savedDist == "miles") {
            rbSettingsMiles.isChecked = true
        } else {
            rbSettingsKm.isChecked = true
        }

        cbSettingsAlerts.isChecked = prefs.getBoolean("receive_alerts", false)

        // Save Settings click listener
        btnSaveSettings.setOnClickListener {
            val updatedDistanceUnit = if (rbSettingsKm.isChecked) "km" else "mi"
            val updatedAlerts = cbSettingsAlerts.isChecked

            prefs.edit().apply {
                putString("unit_distance", updatedDistanceUnit)
                putBoolean("receive_alerts", updatedAlerts)
                apply()
            }

            Toast.makeText(this, getString(R.string.toast_settings_saved), Toast.LENGTH_SHORT).show()
        }

        // Back to Home click listener
        btnBackToHome.setOnClickListener {
            val intent = Intent(this, WelcomeActivity::class.java).apply {
                putExtra("EXTRA_USERNAME", passedUsername)
            }
            startActivity(intent)
            finish()
        }
    }
}