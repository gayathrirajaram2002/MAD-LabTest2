package com.example.travelpass

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class WelcomeActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private var passedUsername: String? = null

    private lateinit var tvWelcomeGreeting: TextView
    private lateinit var tvDistanceUnit: TextView
    private lateinit var tvAlertsStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        prefs = getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
        passedUsername = intent.getStringExtra("EXTRA_USERNAME")

        tvWelcomeGreeting = findViewById(R.id.tvWelcomeGreeting)
        tvDistanceUnit = findViewById(R.id.tvDistanceUnit)
        tvAlertsStatus = findViewById(R.id.tvAlertsStatus)
        val btnGoToProfile = findViewById<Button>(R.id.btnGoToProfile)

        displayProfileDetails()

        btnGoToProfile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java).apply {
                putExtra("EXTRA_USERNAME", passedUsername)
            }
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh preferences display when returning from ProfileActivity or SettingsActivity
        displayProfileDetails()
    }

    private fun displayProfileDetails() {
        val hasProfile = prefs.contains("profile_name")
        val savedName = prefs.getString("profile_name", null)

        if (!hasProfile) {
            Toast.makeText(this, getString(R.string.toast_profile_unavailable), Toast.LENGTH_SHORT).show()
        }

        val travellerName = if (!savedName.isNullOrEmpty()) savedName else passedUsername ?: "Traveller"
        tvWelcomeGreeting.text = getString(R.string.hello_user_format, travellerName)

        val dist = prefs.getString("unit_distance", "km")
        val distFull = if (dist == "mi" || dist == "miles") {
            getString(R.string.unit_miles_full)
        } else {
            getString(R.string.unit_km_full)
        }
        tvDistanceUnit.text = getString(R.string.label_pref_distance, distFull)

        val alerts = prefs.getBoolean("receive_alerts", false)
        val alertsText = if (alerts) getString(R.string.alerts_enabled) else getString(R.string.alerts_disabled)
        tvAlertsStatus.text = getString(R.string.label_pref_alerts, alertsText)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_edit_profile -> {
                val intent = Intent(this, ProfileActivity::class.java).apply {
                    putExtra("EXTRA_USERNAME", passedUsername)
                }
                startActivity(intent)
                true
            }
            R.id.menu_settings -> {
                val intent = Intent(this, SettingsActivity::class.java).apply {
                    putExtra("EXTRA_USERNAME", passedUsername)
                }
                startActivity(intent)
                true
            }
            R.id.menu_logout -> {
                showLogoutConfirmationDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showLogoutConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_logout_title)
            .setMessage(R.string.dialog_logout_message)
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                // Clear saved login credentials from SharedPreferences
                prefs.edit().apply {
                    remove(MainActivity.KEY_REMEMBER)
                    remove(MainActivity.KEY_SAVED_USERNAME)
                    apply()
                }

                Toast.makeText(this, R.string.toast_logged_out, Toast.LENGTH_SHORT).show()

                // Navigate back to MainActivity and clear activity back stack
                val intent = Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                startActivity(intent)
                finish()
            }
            .setNegativeButton(R.string.dialog_no) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}